package org.example.Pages;


import org.checkerframework.checker.units.qual.Force;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import static org.example.StepDefinitions.HOOKS.chromedriver;
public class AddToCartPage
{
    public AddToCartPage()
    {
        PageFactory.initElements(chromedriver,this);
    }
@FindBy(xpath="//div[@class=\"product-content product-wrap clearfix product-deatil\"]//div[@class=\"row\"]//a[@href=\"#\"]")
   public WebElement AddToCartButton;
    @FindBy(css="h2[class=\"name\"]")
  public  WebElement Product;
    @FindBy(css="h3[class=\"price-container\"]")
    public WebElement price;
    @FindBy(css="a[onclick=\"showcart()\"]")
    public WebElement cartTab;
}
