package org.example.StepDefinitions;

import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages.homePage;
import org.example.Pages.PageBase;
import org.example.Pages.LoginWindow;
import  org.example.StepDefinitions.configuration;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.time.Duration;

public class Login extends PageBase
{  homePage home =new homePage();
    LoginWindow Login =new LoginWindow();
 static int switchMessage=0;

    @Given("user goto login page")
    public void userGotoLoginPage()
    {
      home.LoginTab().click();
    }

    @When("user enter a valid account")
    public void userEnterAValidAccount()throws IOException
    {    ExcplicitWaitUntillLocaterBeVisible("//input[@id=\"loginusername\"]");
        String username =configuration.get("username");
        Login.usernameLoginPage.sendKeys(username);

    }

    @And("user enter a valid password")
    public void userEnterAValidPassword() throws IOException
    {
    ExcplicitWaitUntillLocaterBeVisible("//input[@id=\"loginpassword\"]");
    String password =configuration.get("password");
    Login.passwordLoginPage.sendKeys(password);
    }

    @And("user click login button")
    public void userClickLoginButton()
    {
        Login.LogInButton.click();
    }

    @Then("user has successfully logged in")
    public void userHasSuccessfullyLoggedIn() throws IOException, InterruptedException { Thread.sleep(1000);
        SoftAssert soft =new SoftAssert();
        soft.assertFalse(Login.LogInButton.isDisplayed());

        soft.assertEquals(configuration.get("username"),home.NameOfUser().getText());
        System.out.println(home.NameOfUser().getText());

    }


    //NEGATIVE SCENARIO
    @When("user enter an  account {string}")
    public void userEnterAnAccount(String username) {
        ExcplicitWaitUntillLocaterBeVisible("//input[@id=\"loginusername\"]");
        Login.usernameLoginPage.sendKeys(username);
    }

    @And("user enter an  password {string}")
    public void userEnterAnPassword(String password) {
        ExcplicitWaitUntillLocaterBeVisible("//input[@id=\"loginpassword\"]");
        Login.passwordLoginPage.sendKeys(password);
    }

    @And("user click on login button")
    public void userClickOnLoginButton()
    {
        Login.LogInButton.click();
    }

    @Then("alert message would displayed")
    public void alertMessageWouldDisplayed()
    {String ActualMessage ="Wrong password.",ExpectedMessage =ExplicitWaitUntillAlert(Duration.ofSeconds(3));
        SoftAssert soft =new SoftAssert();
        switch(switchMessage)
        {
            case 0:
        soft.assertEquals(ActualMessage,ExpectedMessage);

        break;
            case 1:
                soft.assertEquals(ActualMessage,ExpectedMessage);
         break;
            case 2:
                soft.assertEquals(ActualMessage,ExpectedMessage);
        }
    }
}
