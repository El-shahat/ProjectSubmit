package org.example.StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import jdk.jfr.Unsigned;
import org.example.Pages.AddToCartPage;
import org.example.Pages.Categories;
import org.example.Pages.PageBase;
import org.example.Pages.homePage;
import org.example.StepDefinitions.configuration;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.time.Duration;

import static org.example.StepDefinitions.HOOKS.chromedriver;
public class AddToCart extends PageBase {
    AddToCartPage cart =new AddToCartPage();
    Categories products =new Categories();
    homePage home =new homePage();
   static int price1=0, price2=0,total=0;
   static boolean round =false;
    @Given("user navigate to laptop section")
    public void userNavigateToLaptopSection()throws InterruptedException
    {
        home.LaptobSection().click();
        Thread.sleep(1000);
    }

    @And("user choose the desired laptop {string}")
    public void userChooseTheDesiredLaptop(String product)throws  InterruptedException
    {
   if(product.contains("5"))
   {
       ExcplicitWaitUntillLocaterBeVisible("//div[@class=\"card-block\"]//h4[@class=\"card-title\"]//a[@href=\"prod.html?idp_=8\"]");
       products.product1.click();
   }
   else if(product.contains("7"))
   {

       ExcplicitWaitUntillLocaterBeVisible("//div[@class=\"card-block\"]//h4[@class=\"card-title\"]//a[@href=\"prod.html?idp_=9\"]");
       products.product2.click();}
    }

    @When("user click add to cart")
    public void userClickAddToCart()throws IOException
    {
        if(!round){configuration.set("productName1",cart.Product.getText());
            String Price =cart.price.getText().replaceAll("[^0-9]", "");
            price1= Integer.parseInt(Price);
        configuration.set("productPrice1",String.valueOf(price1));
        round =true;
        }
        else
        {configuration.set("productName2",cart.Product.getText());
            String Price =cart.price.getText().replaceAll("[^0-9]", "");
            price2 =Integer.parseInt(Price);
         configuration.set("productPrice2",String.valueOf(price2));
            round =false;
        }
        total =price1+price2;
     configuration.set("TotalPrice",String.valueOf(total));
     ExcplicitWaitUntillLocaterBeVisible("//div[@class=\"product-content product-wrap clearfix product-deatil\"]//div[@class=\"row\"]//a[@href=\"#\"]");
      cart.AddToCartButton.click();
    }

    @Then("the product would be add to the cart")
    public void theProductWouldBeAddToTheCart()
    {String ExpectedMessage,ActualMessage="Product added";
        SoftAssert soft =new SoftAssert();

      ExpectedMessage= ExplicitWaitUntillAlert(Duration.ofSeconds(5));
      soft.assertEquals(ActualMessage,ExpectedMessage);
      chromedriver.navigate().to("https://www.demoblaze.com/");
    }
}
