package org.example.StepDefinitions;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Key;
import java.util.Properties;

public class configuration {
    //set values inside config.properties from class to config.properties
     public static void set(String key,String value)throws IOException
     {
         Properties property =new Properties();
         FileInputStream fileI =new FileInputStream("config.properties");
         property.load(fileI);
         property.setProperty(key,value);
         fileI.close();
         FileOutputStream fileO =new FileOutputStream("config.properties");
         property.store(fileO,"");
     }
    //call value from Config file   from config.properties to class
    public static String get(String key)throws IOException
    {
        Properties property =new Properties();
        FileInputStream fileI =new FileInputStream("config.properties");
        property.load(fileI);
        String value =property.getProperty(key);
        fileI.close();
        return value;
    }
}
