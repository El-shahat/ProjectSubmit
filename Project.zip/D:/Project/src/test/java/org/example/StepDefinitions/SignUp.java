package org.example.StepDefinitions;

import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages.PageBase;
import org.example.Pages.RegisterWindow;
import org.example.Pages.homePage;
import org.openqa.selenium.Alert;
import org.testng.asserts.SoftAssert;
import static org.example.StepDefinitions.HOOKS.chromedriver;
import org.example.StepDefinitions.configuration;

import java.io.IOException;
import java.time.Duration;

public class SignUp extends PageBase {
    homePage home =new homePage();
    RegisterWindow register =new RegisterWindow();
    @Given("user goto register page")
    public void userGotoRegisterPage()
    {
           home.RegisterTab().click();
    }

    @When("user enter Username")
    public void userEnterUsername()throws  IOException {
        Faker fake =new Faker();
        String username =fake.name().username();
        configuration.set("username",username);
        register.usernameRegisterWindow.sendKeys(username);

     }
    @And("user enter Password")
    public void userEnterPassword() throws IOException {
        Faker fake =new Faker();
        String password =fake.internet().password();
        configuration.set("password",password);
        register.passwordRegisterWindow.sendKeys(password);
    }

    @And("user click sign up button")
    public void userClickSignUpButton() {
        register.SignUpButton.click();
    }

    @Then("user created account successfully")
    public void userCreatedAccountSuccessfully() {
        SoftAssert soft =new SoftAssert();

        String ActualMessageSuccess ="Sign up successful.",ExpectedMassageSuccess =ExplicitWaitUntillAlert(Duration.ofSeconds(10));
        soft.assertEquals(ActualMessageSuccess,ExpectedMassageSuccess);
    }


    @When("user enter same username")
    public void userEnterSameUsername()throws IOException ,InterruptedException {
        register.usernameRegisterWindow.sendKeys(configuration.get("username"));
        Thread.sleep(2000);
    }

    @And("user enter same password")
    public void userEnterSamePassword()throws IOException {
        register.passwordRegisterWindow.sendKeys(configuration.get("password"));
    }

    @Then("user couldn`t create an account")
    public void userCouldnTCreateAnAccount()
    {   String ActualMessage ="This user already exist.",ExcepctedMessage =ExplicitWaitUntillAlert(Duration.ofSeconds(5));
        SoftAssert soft =new SoftAssert();
        soft.assertEquals(ActualMessage,ExcepctedMessage);
    }
}
