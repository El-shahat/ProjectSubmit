package org.example.StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.example.Pages.AddToCartPage;
import org.example.Pages.PageBase;
import org.example.Pages.CartPage;
import org.example.Pages.homePage;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import static org.example.StepDefinitions.HOOKS.chromedriver;
public class CartValidation extends PageBase
{
    static int pN=1;
    homePage home =new homePage();
    CartPage cart =new CartPage();
AddToCartPage cartpage =new AddToCartPage();
    public CartValidation() throws IOException {
    }


    @Then("user find the added product with accurate deatil")

    public void userFindTheAddedProductWithAccurateDeatil() throws IOException, InterruptedException {Thread.sleep(1000);
        String nameProduct;
        int priceProduct,sum=0;
        SoftAssert soft =new SoftAssert();
        while(pN<3)
        {
      //return product name from config.properties
      nameProduct  =cart.CartProductName();
      //return product price from config.properties
      priceProduct =cart.CartProductPrice();
      //summation the total of the products in cart
      sum+=priceProduct;
      //assertion for information of the product
            soft.assertEquals(configuration.get("productName" + String.valueOf(pN)), nameProduct);
            soft.assertEquals(configuration.get(("productPrice") + String.valueOf(pN)), priceProduct);
            soft.assertEquals(configuration.get("TotalPrice"),sum);
        pN++;
        }
        pN=0;
    }
}
