package org.example.StepDefinitions;
import static org.example.StepDefinitions.HOOKS.chromedriver;

import com.github.javafaker.Faker;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Pages.PageBase;
import org.example.Pages.PlaceOrderWindow;
import org.example.Pages.CartPage;
import org.example.StepDefinitions.configuration;
import org.example.Pages.homePage;
import org.testng.asserts.SoftAssert;

import java.io.IOException;

public class purchase extends PageBase
{   homePage home =new homePage();
    CartPage cart =new CartPage();
    PlaceOrderWindow order =new PlaceOrderWindow();
Faker fake =new Faker();
    public purchase() throws IOException {
    }

    @Given("user navigate to cart page")
    public void userNavigateToCartPage()
    {if(!chromedriver.getCurrentUrl().contains("cart"))
      home.CartTab().click();
    }

    @And("user click place older button")
    public void userClickPlaceOlderButton()
    {   ExcplicitWaitUntillLocaterBeVisible("//button[@data-target=\"#orderModal\"]");
        cart.PlaceOrderButton.click();
    }

    @When("user enter name and country and city and card and month and year")
    public void userEnterNameAndCountryAndCityAndCardAndMonthAndYear() throws InterruptedException ,IOException{
      order.name.sendKeys(configuration.get("username"));
      Thread.sleep(1000);
      order.city.sendKeys("Fayoum");
        Thread.sleep(1000);
      order.country.sendKeys("Egypt");
        Thread.sleep(1000);
      order.card.sendKeys("9012 3456 1234 5678");
        Thread.sleep(1000);
      order.month.sendKeys("12");
        Thread.sleep(1000);
      order.year.sendKeys("2026");

    }

    @And("user click purchase")
    public void userClickPurchase()
    {
        order.purchaseButton.click();
    }

    @Then("Purchase confirmation message will appear")
    public void purchaseConfirmationMessageWillAppear()throws InterruptedException
    { Thread.sleep(500);
        SoftAssert soft =new SoftAssert();
         soft.assertTrue( order.Message().getText().contains("Thank you for your purchase!"));
         order.OkMessage.click();
    }
}
