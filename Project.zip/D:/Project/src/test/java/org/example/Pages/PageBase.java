package org.example.Pages;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.example.StepDefinitions.HOOKS.chromedriver;
public class PageBase {
    //this method would generate delay untill alert be visible
    public String ExplicitWaitUntillAlert(Duration time)
    {
        WebDriverWait wait =new WebDriverWait(chromedriver,time);
    Alert alert = wait.until(ExpectedConditions.alertIsPresent());
    String message =alert.getText();
    alert.accept();
    return  message;
    }
    //this method would generate delay untill locator be visible in dom page
 public void ExcplicitWaitUntillLocaterBeVisible(String Xpath)
 {
     WebDriverWait wait =new WebDriverWait(chromedriver, Duration.ofSeconds(10));
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Xpath)));
 }
}
