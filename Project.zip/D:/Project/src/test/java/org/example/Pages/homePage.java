package org.example.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static org.example.StepDefinitions.HOOKS.chromedriver;
public class homePage extends PageBase
{  //apply pom pattern without PageFactor


   public WebElement RegisterTab()
   {
       return chromedriver.findElement(By.xpath("//a[@id='signin2' and contains(@class, 'nav-link')]"));
   }
   public WebElement LoginTab()
   {
       return chromedriver.findElement(By.xpath("//a[@id='login2' and contains(@class, 'nav-link')]"));
   }
   public WebElement NameOfUser()
   {
       return chromedriver.findElement(By.xpath("//a[@id=\"nameofuser\" and contains(@class, 'nav-link')]"));
   }
   public WebElement LaptobSection()
   {   ExcplicitWaitUntillLocaterBeVisible("//a[@onclick=\"byCat('notebook')\"]");
       return chromedriver.findElement(By.cssSelector("a[onclick=\"byCat('notebook')\"]"));
   }
   public WebElement CartTab()
   {   ExcplicitWaitUntillLocaterBeVisible("//div[@id=\"navbarExample\"]//a[@id=\"cartur\"]");
       return chromedriver.findElement(By.cssSelector("a[id='cartur']"));
   }
}
