package org.example.StepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

public class HOOKS {   public static WebDriver chromedriver ;
   static boolean isBrowserOpen =false;
    @Before
    public void openBrowser()
    {   if(!isBrowserOpen)
    {  ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--disable-popup-blocking");
        chromedriver = new ChromeDriver(options);
        chromedriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        chromedriver.manage().window().maximize();
        chromedriver.navigate().to("https://www.demoblaze.com/");}
        isBrowserOpen =true;
    }
    @After
    public void quitBrowser(Scenario scenario) throws InterruptedException {
        Thread.sleep(3000);
        if (chromedriver != null) {
            if (scenario.getName().contains("create a valid account")||scenario.getName().contains("(N)")||scenario.getName().contains("(E)"))
            {
                chromedriver.quit();
                chromedriver = null;
                isBrowserOpen =false;
            }
        }
    }

}
