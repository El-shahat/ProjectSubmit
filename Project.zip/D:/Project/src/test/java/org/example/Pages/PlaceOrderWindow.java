package org.example.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import static org.example.StepDefinitions.HOOKS.chromedriver;
public class PlaceOrderWindow extends PageBase
{
    public PlaceOrderWindow()
    {
        PageFactory.initElements(chromedriver,this);
    }
    @FindBy(css="input[id=\"name\"]")
    public WebElement name;
    @FindBy(css="input[id=\"country\"]")
    public WebElement country;
    @FindBy(css="input[id=\"city\"]")
    public WebElement city;
    @FindBy(css="input[id=\"card\"]")
    public WebElement card;
    @FindBy(css="input[id=\"month\"]")
    public WebElement month;
    @FindBy(css="input[id=\"year\"]")
    public WebElement year;
    @FindBy(css="button[onclick=\"purchaseOrder()\"]")
    public WebElement purchaseButton;
    @FindBy(css="button[class=\"confirm btn btn-lg btn-primary\"]")
    public WebElement OkMessage;
    public WebElement Message()
    {   ExcplicitWaitUntillLocaterBeVisible("//h2");
        return chromedriver.findElements(By.xpath("//h2")).get(2);
    }
}
