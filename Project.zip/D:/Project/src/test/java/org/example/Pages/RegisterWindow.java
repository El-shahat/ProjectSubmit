package org.example.Pages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static org.example.StepDefinitions.HOOKS.chromedriver;
public class RegisterWindow
{
  //apply pom pattern with PageFactor

   public RegisterWindow()
   {
      PageFactory.initElements(chromedriver, this);
   }
   @FindBy(css="input[id=\"sign-username\"]")
   public WebElement usernameRegisterWindow;
   @FindBy(css ="input[type=\"password\"]")
    public WebElement passwordRegisterWindow;
   @FindBy(css ="button[onclick=\"register()\"]")
   public WebElement SignUpButton;
   @FindBy(css ="//div[@class=\"modal-footer\"]//button[@type=\"button\"]")
   public WebElement CloseButton;
   @FindBy(css="span[aria-hidden=\"true\"]")
   public WebElement CloseXbutton;
}
