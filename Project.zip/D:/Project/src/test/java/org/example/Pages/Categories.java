package org.example.Pages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import static org.example.StepDefinitions.HOOKS.chromedriver;
public class Categories extends PageBase
{
      //apply pom pattern With PageFactory
    public Categories()
    {
        PageFactory.initElements(chromedriver,this);
    }

    @FindBy(xpath = "//div[@class=\"card-block\"]//h4[@class=\"card-title\"]//a[@href=\"prod.html?idp_=8\"]")
    public WebElement product1;
    @FindBy(xpath = "//div[@class=\"card-block\"]//h4[@class=\"card-title\"]//a[@href=\"prod.html?idp_=9\"]")
    public WebElement product2;

}
