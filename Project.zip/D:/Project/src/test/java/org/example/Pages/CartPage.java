package org.example.Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.example.StepDefinitions.configuration;

import java.io.IOException;

import static org.example.StepDefinitions.HOOKS.chromedriver;
public class CartPage extends PageBase
{  static  int  switchproduct =0;


    public CartPage() throws IOException {
        PageFactory.initElements(chromedriver,this);
    }


    //apply pom pattern without PageFactor
    public String CartProductName() throws IOException {
        switchproduct++;// for switch between products
        String RelativeXpathOfProductCartName ="//table[@class='table table-bordered table-hover table-striped']//tr[@class='success']/td[contains(text(),"+"'"+configuration.get("productName"+String.valueOf(switchproduct))+"'"+")]";

        return chromedriver.findElement(By.xpath(RelativeXpathOfProductCartName)).getText();
    }
    //get price of the product
    public int CartProductPrice() throws IOException {   String price =PriceOfProduct();
        return Integer.parseInt(price) ;
    }
    //this method would return price as string type
    private String PriceOfProduct() throws IOException { String RelativeXpathOfProductPrice ="//table[@class='table table-bordered table-hover table-striped']//tr[@class='success']/td[contains(text(),"+"'"+configuration.get("productPrice"+String.valueOf(switchproduct))+"'"+")]";
        return chromedriver.findElement(By.xpath(RelativeXpathOfProductPrice)).getText().replaceAll("^[0-9]","");
    }

@FindBy(css="button[data-target=\"#orderModal\"]")
public WebElement PlaceOrderButton;
}
