package org.example.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import static org.example.StepDefinitions.HOOKS.chromedriver;
public class LoginWindow

{

    //apply pom pattern with PageFactory
    public LoginWindow()
    {
        PageFactory.initElements(chromedriver,this);
    }
    @FindBy(css="input[id=\"loginusername\"]")
   public WebElement usernameLoginPage;
    @FindBy(css="input[id=\"loginpassword\"]")
   public WebElement passwordLoginPage;
    @FindBy(css="button[onclick=\"logIn()\"]")
   public WebElement LogInButton;
    @FindBy(css="button[onclick=\"logOut()\"]")
    public WebElement LogOutButton;
}
